function navTo(x){
	window.location.href = x+".html";
}