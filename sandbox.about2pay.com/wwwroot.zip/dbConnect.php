<?php

//SANDBOX
$dbHost = 'instapaymysql.mysql.database.azure.com';
$dbUsername = 'instapayadmin@instapaymysql';
$dbPassword = '9GtbqKsW9LbRyGWQ3LG8';
$dbName = 'instapay_sandbox';

$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
else{
	// echo 'connected';
}
?>