<?php
    session_start();
	//echo $_SESSION["tokenId"];
    //foreach ($_POST as $key => $value)
    //    echo $key.'='.$value.'<br />';
	// GET STATUS from EFT / Masterpass


	// call payment request

	// get merchant data

	// route back to merchant website
?>
<html>


<body style="background-color:#f8f8f8">
<div style="text-align:center">
<br/>
 <img style="height:200px" src="images/payment_complete.png"></img>

<br/>


<p>The payment process is complete</p>
<p>You will be redirected back to the online shop in a few seconds.</p>
<p>Take note that if you selected any offline payment option, your order </p>
<p>will not be finalised until payment is received.</p>


</div>





</body>
<script src="js/jquery.min.js"></script>
<script src="js/md5.min.js"></script>
<script>
    ordernr="<?php echo $_SESSION["m_tx_order_nr"] ?>";
	invoicenr="<?php echo $_SESSION["m_tx_invoice_nr"] ?>";
	itemname="<?php echo $_SESSION["m_tx_item_name"] ?>";
	duedate="<?php echo $_SESSION["m_tx_due_date"] ?>";
	tokenId="<?php echo $_SESSION["tokenId"] ?>";
	returnurl="<?php echo $_SESSION["m_return_url"] ?>";
	notifyurl="<?php echo $_SESSION["m_notify_url"] ?>";
	currency="<?php echo $_SESSION["m_tx_currency"] ?>";
	console.log(ordernr,invoicenr,itemname,duedate);
	setTimeout(function(){
		var reqOpt={
			tokenId:tokenId,
			opt:"loadPaymentToken"
		};
				$.ajax({
					url:'php/getClientPaymentMethods.php',type: 'POST',cache: false,data: JSON.stringify(reqOpt),contentType: 'application/json',dataType: 'json',
					success: function (data) {
						    //document.getElementById("demo").innerHTML = reqOpt.tokenId+" "+data.status+" OrderId:"+localStorage.getItem("m_tx_invoice_nr");
							//console.log(localStorage.getItem("m_tx_invoice_nr"));
						    var result={};
							//alert(JSON.stringify(data));
							result.payeeOrderItemDescription=data.description;
							result.payeeUuid=data.payee.accountUuid;
							if (data.payee.category1) result.payeeCategory1=data.payee.category1;
							if (data.payee.category2) result.payeeCategory2=data.payee.category2;
							if (data.payee.category3) result.payeeCategory3=data.payee.category3;
							if (data.payee.siteName) result.payeeSiteName=data.payee.siteName;
							if (data.payee.siteRefInfo) result.payeeSiteReference=data.payee.siteRefInfo;
							if (data.payee.refInfo) result.payeeRefInfo=data.payee.refInfo;
							result.payeeOrderNr=ordernr;
							result.payeeAccountUuid=data.payee.accountUuid;
							result.payeeInvoiceNr=invoicenr;
							result.payeeOrderItemName=itemname;
							//result.payeePaymentDueDate=duedate;
							result.requestTokenId=data.tokenId;
							//result.paymentFeeAmount=0;
							result.paymentAmount=data.amount;
							result.paymentCurrency=currency;
							result.paymentDateTime=new Date().toISOString();
							result.paymentStatus=data.status;
							result.paymentType="RECEIPT";
							result.paymentSystemReference=data.systemRefInfo;
							result.paymentMethod="EFT_INSTANT";
							result.payerName=data.payer.name;
							result.payerSurname=data.payer.surname;
							result.payerEmail=data.payer.email;
							var amt=data.amount.toFixed(2);
							result.paymentAmount=amt;
							result.requestAmount=amt;
							result.requestCurrency='ZAR';
							result.requestStatus=data.status;
							console.log(amt);
							var amt2=amt.replace(/\D/g,'')
							var csa=[data.payee.accountUuid,data.payee.accountUuid,data.payee.refInfo,amt2,'ZAR','TLS_secret'];
							result.checksum=md5(csa.join('_'));											
							result.notifyurl=notifyurl;
							//alert(JSON.stringify(result));

							$.ajax({
								url:"php/notifyResponse.php",type: 'POST',cache: false,data: JSON.stringify(result),contentType: 'application/json',
								success: function (data) {
									window.location=returnurl;
									console.log("DATA",data);
								},
								error: function(result, status, error) {
									console.log( 'something went wrong', JSON.stringify(status), JSON.stringify(error));
								}
							});
					}
				});
	}, 2000);
</script>
