<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thanks</title>
</head>
<body>
	Thank you 
</body>
</html>