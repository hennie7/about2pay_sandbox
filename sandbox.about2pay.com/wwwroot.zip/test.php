<?php
   print_r($_POST);
	
   echo $_POST["amount"];
	// call payment request
	
	// get merchant data
	
	// route back to merchant website
?>
