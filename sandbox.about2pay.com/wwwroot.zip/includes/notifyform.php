	<form name="Form1" method="post" action="https://paymentgateway.tlsag.com/test.php" id="Form1">
          <input type="hidden" name="amount" value="10">
      </form>
<script>
   var FORM=document.getElementById('Form1');
   FORM.submit();
</script>