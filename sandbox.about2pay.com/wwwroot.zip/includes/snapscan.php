            

				     <br/>
          <div style="text-align:center">
  					<img src="images/snapscan.png" alt="Masterpass Logo">
          </div>


					<h3 style="color: #2b2b2b;">Steps to make a payment using Snapscan</h3>
  					<ol  style="text-align:left">
  						<li>Open any SnapScan mobile app on you smartphone device.</li>
  						<li>Ensure that you have a valid bank card linked to your profile or that there is sufficient funds available for the payment.</li>
  						<li>Select the option to scan the QR code (Camera button).</li>
  						<li>Scan the QR code displayed or enter the 10-digit code manually.</li>
              <li>Follow the process within the mobile app to complete the payment.</li>
  					</ol>
                  <br/>
            <div id="zapscanqr" style="text-align:center"></div>
			      <br/>
            <div style="text-align:center">
              <h1 id="zapscancode"></h1>
              <button style="background-color:gold" href="http://paymentgateway.tlsag.com/result.php">Back to shopping</button>
            </div>
            <br/>
 <button style="width:300px" class="panelCloseBtn printHide"  data-html2canvas-ignore onclick="changeChoice()">Select another payment method</button>